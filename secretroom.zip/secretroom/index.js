const { Client, GatewayIntentBits, ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType, PermissionsBitField } = require('discord.js');
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildVoiceStates
    ]
});

const prefix = "!";
let panelKanal = null;
let sesKanal = null;

client.on('ready', () => {
    console.log(`${client.user.tag} olarak giriş yapıldı!`);
});

client.on('messageCreate', async message => {
    if (!message.content.startsWith(prefix) || message.author.bot) return;

    const args = message.content.slice(prefix.length).trim().split(/ +/);
    const command = args.shift().toLowerCase();

    if (command === 'panelkanalıayarla') {
        if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return message.reply('Bu komutu kullanmak için yönetici yetkisine sahip olmalısınız!');
        }

        const kanal = message.mentions.channels.first();
        if (!kanal) return message.reply('Lütfen bir kanal etiketleyin!');

        panelKanal = kanal.id;
        
        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('ozeloda_olustur')
                    .setLabel('Özel Oda Oluştur')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('kanal_sil')
                    .setLabel('Kanalı Sil')
                    .setStyle(ButtonStyle.Danger)
            );

        await kanal.send({
            content: '🎮 Özel Oda Kontrol Paneli',
            components: [row]
        });

        message.reply('Panel kanalı başarıyla ayarlandı!');
    }

    if (command === 'sesayarla') {
        if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return message.reply('Bu komutu kullanmak için yönetici yetkisine sahip olmalısınız!');
        }

        const kanal = message.mentions.channels.first();
        if (!kanal) return message.reply('Lütfen bir ses kanalı etiketleyin!');
        if (kanal.type !== ChannelType.GuildVoice) return message.reply('Lütfen bir ses kanalı etiketleyin!');

        sesKanal = kanal.id;
        message.reply('Ses kanalı başarıyla ayarlandı!');
    }
});

client.on('interactionCreate', async interaction => {
    if (!interaction.isButton()) return;

    if (interaction.customId === 'ozeloda_olustur') {
        const channel = await interaction.guild.channels.create({
            name: `🎮│${interaction.user.username}`,
            type: ChannelType.GuildVoice,
            parent: interaction.channel.parentId,
            permissionOverwrites: [
                {
                    id: interaction.guild.id,
                    deny: [PermissionsBitField.Flags.ViewChannel],
                },
                {
                    id: interaction.user.id,
                    allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.ManageChannels],
                }
            ]
        });

        await interaction.reply({ content: `Özel odanız oluşturuldu: ${channel}`, ephemeral: true });
    }

    if (interaction.customId === 'kanal_sil') {
        const userChannel = interaction.guild.channels.cache.find(
            c => c.name === `🎮│${interaction.user.username}` && c.type === ChannelType.GuildVoice
        );

        if (!userChannel) {
            return interaction.reply({ content: 'Silinecek bir kanalınız bulunmuyor!', ephemeral: true });
        }

        await userChannel.delete();
        await interaction.reply({ content: 'Kanalınız başarıyla silindi!', ephemeral: true });
    }
});

client.on('voiceStateUpdate', async (oldState, newState) => {
    if (!sesKanal) return;
    if (newState.channelId === sesKanal) {
        const channel = await newState.guild.channels.create({
            name: `🎮│${newState.member.user.username}`,
            type: ChannelType.GuildVoice,
            parent: newState.channel.parentId,
            permissionOverwrites: [
                {
                    id: newState.guild.id,
                    deny: [PermissionsBitField.Flags.ViewChannel],
                },
                {
                    id: newState.member.id,
                    allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.ManageChannels],
                }
            ]
        });

        await newState.setChannel(channel);
    }
});

client.login('TOKEN_BURAYA');
